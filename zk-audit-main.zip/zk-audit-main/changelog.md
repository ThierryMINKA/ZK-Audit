# Changelog – ZK-Audit

This file tracks all major changes, additions, and revisions to the ZK-Audit project.

---

## v1.0 – Submission to ICTO 2025 (March 2025)

- Finalized full paper and appendices for submission.
- Reorganized all references and cross-appendix links.
- Consolidated symbolic model, glossary, and benchmark tables.
- Produced final README and structured GitHub architecture.
- Documented GDPR compliance mechanism and BLS/Dilithium hybrid strategy.

---

## v0.3 – Cryptographic Formalization and Integration Design

- Added formal cryptographic assumptions (Appendix D).
- Integrated hybrid signature strategy BLS → Dilithium (Section 7.4).
- Added symbolic security model (Appendix F – Tamarin).
- Completed visual flows: GDPR deletion, SIEM integration (Figures A.3, A.4).
- Inserted projected benchmark estimations (Appendix E).

---

## v0.2 – Methodology and Architecture Foundations

- Completed pseudocode and explained each function line-by-line (Appendix B).
- Generated reference Python code for Merkle tree, zk-STARK simulation, BLS aggregation (Appendix C).
- Structured paper methodology with formulas, models and cross-references.
- Added comparative analysis (Appendix H) and glossary (Appendix G).

---

## v0.1 – Initial Research Release and Paper Drafting

- Defined system model (Logger, Prover, Verifier, Storage).
- Outlined integration targets (Wazuh, Elasticsearch).
- Drafted initial abstract, introduction, and contribution roadmap.
- Began pseudocode definition and architecture schematics (Figure A.1).
